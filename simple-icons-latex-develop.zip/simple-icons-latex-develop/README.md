# Simple Icons LaTeX

This package aims to provide [Simple Icons](https://github.com/simple-icons/simple-icons) for LaTeX like [fontawesome-latex](https://github.com/xdanaux/fontawesome-latex/). Please refer to the manual and Simple Icons for more details.

---

Simple Icons / Simple Icons Font<br/>
Author: Simple Icons Collaborators<br/>
Licence: Creative Commons Zero v1.0 Universal<br/>
URL: <https://simpleicons.org/> <https://github.com/simple-icons/simple-icons-font>

simpleicons LaTeX package<br/>
Author: Inesh Bose (Inesh.Bose@glasgow.ac.uk)<br/>
Licence: Creative Commons Zero v1.0 Universal<br/>
URL: <https://github.com/ineshbose/simple-icons-latex>
